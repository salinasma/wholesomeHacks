'use strict';

angular.
module('personalFinances').
component('personalFinances', {
    templateUrl: 'personalFinances/personalFinances.template.html',
    controller: function UserListController($http, $scope , $timeout, $mdSidenav,NgTableParams) {
        }
       
    
    }
});


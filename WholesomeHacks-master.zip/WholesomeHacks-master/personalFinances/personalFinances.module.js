'use strict';

// Define the `phoneList` module
angular.module('personalFinances', [ 
        'ngMaterial', 
        'ngMessages' , 
        'material.svgAssetsCache',
        'navBar',
        'toast',
        'ngTable',
        'chart.js'

]);

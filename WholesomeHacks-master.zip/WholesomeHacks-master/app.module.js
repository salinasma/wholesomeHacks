'use strict';

angular.module('mainApp', [
  'mainPage'
]);

angular.module('tiles', [
    'ngMaterial', 
    'ngMessages', 
    'material.svgAssetsCache', 
    'timer'

]);
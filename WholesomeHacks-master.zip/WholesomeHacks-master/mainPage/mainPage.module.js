'use strict';

// Define the `phoneList` module
angular.module('mainPage', [ 
        'ngMaterial',
        'tiles'

]);

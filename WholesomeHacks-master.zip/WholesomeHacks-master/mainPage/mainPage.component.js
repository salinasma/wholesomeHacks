'use strict';

angular.
module('mainPage').
component('mainPage', {
    templateUrl: 'mainPage/mainPage.template.html',
    controller: function UserListController($http, $scope , $timeout) {

       

    }
});


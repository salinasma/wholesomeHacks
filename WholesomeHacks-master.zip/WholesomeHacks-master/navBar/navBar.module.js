'use strict';


angular.module('navBar',[
    'ngMaterial',
    'ngMessages', 
    'material.svgAssetsCache',
    'financialTracker'
]);
